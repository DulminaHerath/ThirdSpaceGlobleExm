export interface Contact{
    _id:string;
    firstname:string;
    lastname:string;
    phone:string;
    emptype:string;
    

}