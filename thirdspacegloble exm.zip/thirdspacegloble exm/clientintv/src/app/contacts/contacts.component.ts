import { Component, OnInit,AfterViewInit, ViewChild } from '@angular/core';
import { ContactsService } from '_services/contacts.service';
import { Contact } from '../_modles/contact';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';


@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css'],
})
export class ContactsComponent implements OnInit {
  masterColor!: FormGroup;
  contacts!: Contact[];
  contact!: Contact;

  constructor(
    private ContactServices: ContactsService,
    private fb: FormBuilder
  ) {
    //this.contacts = [];
  }

  ngOnInit(): void {
    this.initilizeForm();
    this.LoadColorCard();
  }

  initilizeForm() {
    this.masterColor = this.fb.group({
      _id: [0],
      firstname: ['', [Validators.required, Validators.maxLength(20)]],
      lastname: ['', [Validators.required, Validators.maxLength(20)]],
      phone: ['', [Validators.required, Validators.maxLength(10)]],
      emptype:['', [Validators.required, Validators.maxLength(15)]],
    });
  }

  LoadColorCard() {
    this.ContactServices.getContacts().subscribe((contactlist) => {
      this.contacts = contactlist;
      console.log("dd",this.contacts);
    });
  }

  deleteContact(id:any){
    console.log(id);
    this.ContactServices.deleteContacts(id).subscribe((data)=>{   
        console.log(data);
      
    })
    this.LoadColorCard();
  }

  addContact(){
    const newContact={
      firstname:this.contact.firstname,
    }
    console.log(newContact)
  }
}
