import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../src/environments/environment';
import {Contact} from '../src/app/_modles/contact';


@Injectable({
  providedIn: 'root'
})
export class ContactsService {

  baseUrl = environment.apiUrl;
  constructor(private http:HttpClient) { }

  getContacts(){
    return this.http.get<Contact[]>(this.baseUrl +'contacts');
  }
  saveContacts(model: Contact) {
    return this.http.post(this.baseUrl + 'contacts', model);
  }
  deleteContacts(id:any) {
    return this.http.delete(this.baseUrl + 'contacts/'+`${id}`);
  }

}
