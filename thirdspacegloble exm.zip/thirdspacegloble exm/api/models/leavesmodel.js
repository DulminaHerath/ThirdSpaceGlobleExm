const mongoose = require("mongoose");

const LeavesSchema = mongoose.Schema({
    userid: {
    type: String,
    require: true,
  },
  casualavalible: {
    type: String,
    require: true,
  },
  medicalavalible: {
    type: String,
    require: true,
  },
  annualavalible: {
    type: String,
    require: true,
  },
  casualavalgot: {
    type: String,
    require: true,
  },
  medicalgot: {
    type: String,
    require: true,
  },
  annualgot: {
    type: String,
    require: true,
  },
});

const leavesbyusr = (module.exports = mongoose.model("leavesbyusr", LeavesSchema));
