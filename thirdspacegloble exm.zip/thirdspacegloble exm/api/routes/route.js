const express = require("express");
const { db } = require("../models/contacsmodels");
const router = express.Router();

const Contact = require("../models/contacsmodels");
const leavesbyusr=require("../models/leavesmodel")

//view data emp
router.get("/contacts", (req, res, next) => {
  Contact.find(function (err, contacts) {
    res.json(contacts);
  });
  // res.send('Retrieving the contact list');
});

//view data leaves
router.get("/leavesbyusr", (req, res, next) => {
  leavesbyusr.find(function (err, leavesbyusr) {
    res.json(leavesbyusr);
  });
  // res.send('Retrieving the contact list');
});


// router.get('/',(req,res)=>{
//     res.send('<h1>footbar</h>');
// })

//add deta leaves
router.post("/leavesbyusr", (req, res, next) => {
  let newleave = new leavesbyusr({
    userid: req.body.userid,
    casualavalible: req.body.casualavalible,
    medicalavalible: req.body.medicalavalible,
    annualavalible: req.body.annualavalible,
    casualavalgot: req.body.casualavalgot,
    medicalgot: req.body.medicalgot,
    annualgot: req.body.annualgot,
  });

  db.get
  leavesbyusr.updateMany((err, leave) => {
    if (err) {
      res.json({ msg: "faild to add contact" });
    } else {
      res.json({ msg: "contact added sucssfully" });
    }
  });
  // res.send('add the contact list');
});

//delete data
// router.delete("/contacts/:id", (req, res, next) => {
//   Contact.remove({ _id: req.params.id }, function (err, result) {
//     if (err) {
//       res.json(err);
//     } else {
//       res.json(result);
//     }
//   });
//   // res.send('delete the contact list');
// });

module.exports = router;
